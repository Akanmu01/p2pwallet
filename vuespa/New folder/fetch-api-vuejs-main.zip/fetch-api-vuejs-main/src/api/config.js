export const APISettings = {
    token: '',
    headers: new Headers({
        'Accept': 'application/json'
    }),
    baseURL: 'https://api.roastandbrew.coffee/api/v1',
}