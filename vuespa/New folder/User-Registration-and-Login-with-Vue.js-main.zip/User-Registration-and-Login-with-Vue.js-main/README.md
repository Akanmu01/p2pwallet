# Formulaire d'inscription avec vueJS

Le processus d'enregistrement et de connexion est l'une des caractéristiques les plus importantes de presque toutes les plateformes numériques. C'est tellement important que les E-commerces ou les plateformes SAAS utilisent généralement l'enregistrement comme l'une de leurs API. 

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
# User-Registration-and-Login-with-Vue.js
